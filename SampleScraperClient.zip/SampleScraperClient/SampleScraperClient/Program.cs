﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using ScrapySharp.Core;
using ScrapySharp.Html.Parsing;
using ScrapySharp.Network;
using HtmlAgilityPack;
using ScrapySharp.Extensions;
using ScrapySharp.Html.Forms;
using System.IO;
using System.Globalization;
using System.Web.Script.Serialization;

namespace SampleScraperClient
{
    class Program
    {

     /*   public static async void testasync()
        {
            String query = "curl - X POST--header 'Content-Type: application/json'--header 'Accept: application/json'--header 'x-app-id: 37b5e732'--header 'x-app-key: 758e901ffc110d2a04e552bd0fb8d395'--header 'x-remote-user-id: 0' - d '{\"query\": \"One tablespoon of sugar\"}'";

            HttpClient client = new HttpClient();
            FormUrlEncodedContent requestContent = new FormUrlEncodedContent(new[] {
    new KeyValuePair<string, string>("text", query),
});
            HttpResponseMessage response = await client.PostAsync(
    "https://trackapi.nutritionix.com/v2/natural/nutrients",
    requestContent);
            HttpContent responseContent = response.Content;
            using (var reader = new StreamReader(await responseContent.ReadAsStreamAsync()))
            {
                // Write the output.
                Console.WriteLine(await reader.ReadToEndAsync());
            }
           // string result = responseContent.ToString();
           // result = result.Substring(0, result.Length);
        }*/
        public static string getBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                if (End == -1)
                {
                    return "";
                }
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }
        static void Main(string[] args)
        {
            System.IO.StreamWriter file = new System.IO.StreamWriter("c:\\output\\sizeofitems.txt");

            int counter = 1;
            // setup the browser
            ScrapingBrowser Browser = new ScrapingBrowser();
            Browser.AllowAutoRedirect = true; // Browser has many settings you can access in setup
            Browser.AllowMetaRedirect = true;
            //go to the home page
            List<string> listA = new List<string>();
            using (var fs = File.OpenRead(@"C:\just_urls.csv"))
            using (var reader = new StreamReader(fs))
            {
                // List<string> listB = new List<string>();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var line2 = line.Substring(4);
                    int seperate = line2.IndexOf("\"");
                    var line3 = line2.Substring(0, seperate);
                    listA.Add(line3);

                }
            }
            foreach (string elements in listA)
            {
                
                WebPage PageResult = Browser.NavigateToPage(new Uri(elements));
                // get first piece of data, the page title
                List<String> items = new List<string>();
                List<String> ingredents = new List<string>();
                String test1 = PageResult.Content;
                String test3 = "";
                while (test1 != null)
                {
                    String test2 = getBetween(test1, "itemprop=\"ingredients\">", "</li>\n\t\t\t\t\n\t\t\t\t");
                    int Starter = test1.IndexOf("itemprop=\"ingredients\">", 0) + "itemprop=\"ingredients\">".Length + test2.Length;
                    if (Starter != 0)
                    {
                        if (test2 == "")
                        {
                            if (test3.Contains("Note"))
                            {
                                break;
                            }
                            else
                            {
                                test3 = test3.Replace('\n', ' ');
                                items.Add(test3);
                                break;
                            }
                        }
                        else
                        {
                            if (test2.Contains("_"))
                            {
                                Starter = test1.IndexOf("itemprop=\"ingredients\">", 0) + "itemprop=\"ingredients\">".Length + test2.Length;
                                test1 = test1.Substring(Starter);
                                test2 = getBetween(test1, "itemprop=\"ingredients\">", "</li>\n\t\t\t\t\n\t\t\t\t");
                            }
                            else
                            {
                                test2.Replace("\n", "");
                                items.Add(test2);
                            }
                        }
                    }
                    test1 = test1.Substring(Starter);
                    test3 = getBetween(test1, "itemprop=\"ingredients\">", "</li>\n\t\t\t\t\n\t\t\t\n\t\t");
                }
                //     testasync();
                //     while (true)
                //     {

                //            }

                string path = "https://trackapi.nutritionix.com/v2/natural/nutrients";
                //string path2 = "?queryString=One tablespoon of sugar";
                // string result = path + path2;
                float sum = 0;
                string value = "";
                foreach (string element in items)
                {
                    var httpWebRequest = (HttpWebRequest)WebRequest.Create(path);
                    httpWebRequest.ContentType = "application/json";
                    httpWebRequest.Accept = "application/json";
                    httpWebRequest.Headers.Add("x-app-id", "fc817b65");
                    httpWebRequest.Headers.Add("x-app-key", "0ea6526c855e491d3139a633f72f57ad");
                    httpWebRequest.Headers.Add("x-remote-user-id", "0");

                    httpWebRequest.Method = "POST";
                    using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                    {
                        string data = "{\"query\": \"" + element + "\"}";

                        streamWriter.Write(data);
                    }

                    //string strNewValue = "-d " + items[0];

                    try
                    {
                        HttpWebResponse resp = (HttpWebResponse)httpWebRequest.GetResponse();
                        string respStr = new StreamReader(resp.GetResponseStream()).ReadToEnd();
                        //Console.WriteLine(respStr);
                        //Console.WriteLine();
                        int startpoint = respStr.IndexOf("serving_weight_grams") + "serving_weight_grams".Length;
                        string respStr2 = respStr.Substring(startpoint + 2);
                        //Console.WriteLine(respStr2);
                        int finishpoint = respStr2.IndexOf(',');
                        respStr2 = respStr2.Substring(0, finishpoint);

                        int startpoint2 = respStr.IndexOf("food_name") + "food_name".Length;
                        string respStr3 = respStr.Substring(startpoint2 + 2);
                        //Console.WriteLine(respStr3);
                        int finishpoint2 = respStr3.IndexOf(',');
                        respStr3 = respStr3.Substring(1, finishpoint2-2);
                         value = value + respStr3 + "," + respStr2 + ",";
                        

                    }
                    catch
                    {
                        Console.WriteLine("Can't calculate the sum of calories");
                        Console.WriteLine(counter);
                        //sum = 0;
                        break;
                    }

                }
                
                    file.WriteLine(value);
                
//                file.WriteLine("----------------");
                //string line = "sum of calories for recepie " + counter.ToString() + " is " + sum.ToString();

                // Write the string to a file.
                //file.WriteLine(line);

                
                //Console.WriteLine("sum of calories for recepie " + counter + " is " + sum);
                sum = 0;
                counter++;
            }
            file.Close();
            //float s = float.Parse(respStr);
            // Console.WriteLine("Response : " + respStr);
            //var client = new RestClient("https://example.com/?urlparam=true");
            //var request = new RestRequest(Method.POST);

            // String test2 = PageResult.FindFormById("ingredients");

        }
    }
}
